// ignore_for_file: deprecated_member_use

import 'package:flutter/material.dart';
import '../service/brapi_service.dart';
import '../widgets/barra_tecnologica.dart';
import '../widgets/detalhes_cotacao_widget.dart';

class CompararAcoesPage extends StatefulWidget {
  const CompararAcoesPage({super.key});

  @override
  State<CompararAcoesPage> createState() => _CompararAcoesPageState();
}

class _CompararAcoesPageState extends State<CompararAcoesPage> {
  final _controller = TextEditingController();
  final _apiService = BrapiService();
  final _acoes = <String>[];
  List<dynamic>? _resultados;
  bool _loading = false;

  static const Color brapiBlue = Color(0xFF3B82F6);
  static const Color brapiDarkBg = Color(0xFF0F172A);
  static const Color brapiCardBg = Color(0xFF1E293B);
  static const Color brapiAccent = Color(0xFF60A5FA);

  void _adicionarAcao() {

    final acao = _controller.text.toUpperCase().trim();
    if (acao.isNotEmpty && !_acoes.contains(acao) && _acoes.length < 2) {
      // Adiciona a açao a lista
      setState(() {
        _acoes.add(acao);
        _controller.clear();
        if (_acoes.length == 2) _compararAcoes();
      });
    }
  }

  void _removerAcao(String acao) {
    setState(() {
      _acoes.remove(acao);
      _resultados = null;
    });
  }

  Future<void> _compararAcoes() async {
    //busca os dados
    setState(() => _loading = true);
    try {
    
      final dados = await _apiService.buscarMultiplasCotacoes(_acoes);
      // atualiza os resultados
      setState(() {
        _resultados = dados;
        _loading = false;
      });
    } catch (e) {
      setState(() => _loading = false);
      if (mounted) {
        // mostra a mensagem de erro
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Erro: $e'), backgroundColor: Colors.red),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(

      appBar: AppBar(
        backgroundColor: brapiCardBg,
        title: const Text(
          'COMPARAR AÇÕES',
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.w700,
            letterSpacing: 2.5,
          ),
        ),
        centerTitle: true,
    
        iconTheme: const IconThemeData(color: brapiBlue),
        elevation: 0,
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(3),
          child: BarraTecnologica(color: brapiBlue),
        ),
      ),
      backgroundColor: brapiDarkBg,

      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                Row(
                  children: [
                    Expanded(
                      // campo de texto para adicionar açao
                      child: TextField(
                        controller: _controller,
                        decoration: InputDecoration(
                          labelText: "CÓDIGO DA AÇÃO (EX: PETR4)",
                          labelStyle: TextStyle(
                            color: brapiAccent,
                            fontSize: 11,
                            fontWeight: FontWeight.w600,
                            letterSpacing: 1.2,
                          ),
    
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(8),
                          ),
                          enabledBorder: OutlineInputBorder(
                            borderSide: BorderSide(color: brapiBlue, width: 2),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderSide: BorderSide(color: brapiBlue, width: 2),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          // campo de texto para adicionar açao
                          filled: true,
                          fillColor: brapiCardBg,
                        ),


                        // estilo do texto digitado
                        style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w700,
                          letterSpacing: 1.5,
                        ),
                        textCapitalization: TextCapitalization.characters,
                        onSubmitted: (_) => _adicionarAcao(),
                        enabled: _acoes.length < 2,
                      ),
                    ),

                    // botão de adicionar açao
                    const SizedBox(width: 10),
                    Container(
                      decoration: BoxDecoration(
                        color: brapiBlue.withOpacity(0.1),
                        border: Border.all(color: brapiBlue, width: 2),
                        borderRadius: BorderRadius.circular(8),
                        boxShadow: [
                          BoxShadow(
                            color: brapiBlue.withOpacity(0.20),
                            blurRadius: 8,
                          ),
                        ],
                      ),

                      // ícone do botão
                      child: IconButton(
                        onPressed: _acoes.length < 2 ? _adicionarAcao : null,
                        icon: const Icon(Icons.add, color: brapiBlue),
                        iconSize: 28,
                      ),
                    ),
                  ],
                ),
                // exibe as ações adicionadas
                if (_acoes.isNotEmpty) ...[
                  // lista de chips com as ações POP UOPPPPPPPP
                  const SizedBox(height: 10),
                  Wrap(
                    spacing: 8,
                    children: _acoes
                        .map(
                          (acao) => Chip(
                            label: Text(
                              acao,
                              style: const TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.w700,
                                letterSpacing: 1.5,
                              ),
                            ),
                            backgroundColor: brapiBlue,
                            deleteIcon: const Icon(
                              Icons.close,
                              size: 18,
                              color: Colors.white,
                            ),
                            onDeleted: () => _removerAcao(acao),
                            side: BorderSide.none,
                          ),
                        )
                        // converte a lista de açoes em chips
                        .toList(),
                  ),
                ],
              ],
            ),
          ),
          // exibe os resultados da comparação
          Expanded(
            child: _loading
                ? const Center(
                    child: CircularProgressIndicator(color: brapiBlue),
                  )
                  // verifica se há dois resultados para comparar
                : _resultados != null && _resultados!.length == 2

                // exibir os detalhes das cotações para comparação em dupla!!!!!!!!!!!!!!
                ? PageView.builder(
                    itemCount: 2,
                    itemBuilder: (context, index) => Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      child: DetalhesCotacaoWidget(data: _resultados![index]),
                    ),
                  )
                : Center(
                  // mensagem para adicionar ações
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Container(
                          // ícone de comparação
                          padding: const EdgeInsets.all(20),
                          decoration: BoxDecoration(
                            color: brapiBlue.withOpacity(0.1),
                            border: Border.all(color: brapiBlue, width: 2),
                            borderRadius: BorderRadius.circular(50),
                          ),
                          child: const Icon(
                            Icons.compare_arrows,
                            color: brapiBlue,
                            size: 60,
                          ),
                        ),
                        const SizedBox(height: 20),
                        Text(
                          "ADICIONE 2 AÇÕES PARA COMPARAR",
                          style: TextStyle(
                            color: brapiAccent,
                            fontSize: 11,
                            fontWeight: FontWeight.w600,
                            letterSpacing: 1.5,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ],
                    ),
                  ),
          ),
        ],
      ),
    );
  }

  @override
  // libera os recursos do controlador
  void dispose() {
    _controller.dispose();
    super.dispose();
  }
}

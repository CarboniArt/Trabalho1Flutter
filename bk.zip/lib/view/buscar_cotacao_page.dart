// ignore_for_file: deprecated_member_use

import 'package:flutter/material.dart';
import '../service/brapi_service.dart';
import '../widgets/barra_tecnologica.dart';
import '../widgets/detalhes_cotacao_widget.dart';

class BuscarCotacaoPage extends StatefulWidget {
  final String?
  tickerInicial; // Paremetro opcional para receber ticker de outra tela

  const BuscarCotacaoPage({super.key, this.tickerInicial});

  @override
  State<BuscarCotacaoPage> createState() => _BuscarCotacaoPageState();
}

class _BuscarCotacaoPageState extends State<BuscarCotacaoPage> {
  String? ticker;
  Future<Map<String, dynamic>>? _future;
  final apiService = BrapiService();
  final TextEditingController _textController = TextEditingController();

  static const Color brapiBlue = Color.fromARGB(255, 121, 160, 223);
  static const Color brapiDarkBg = Color(0xFF0F172A);
  static const Color brapiCardBg = Color(0xFF1E293B);

  @override
  void initState() {
    super.initState();
    // Se recebeu um ticker inicial, busca automaticamente
    if (widget.tickerInicial != null) {
      _textController.text = widget.tickerInicial!;
      WidgetsBinding.instance.addPostFrameCallback((_) {
        _buscarTicker(widget.tickerInicial!);
      });
    }
  }

  @override

  void dispose() {
    // Limpar o controlador de texto ao descartar a pagina
    _textController.dispose();
    super.dispose();
  }

  String? validarTicker(String ticker) {
    if (ticker.isEmpty) {
      return 'Digite o código de uma ação';
    }

    if (!RegExp(r'^[A-Z0-9]+$').hasMatch(ticker)) {
      return 'O código contém caracteres inválidos. Use apenas letras e números.';
    }

    if (ticker.length < 4) {
      return 'O código está muito curto. Ex: PETR4 (mínimo 4 caracteres)';
    }

    if (ticker.length > 6) {
      return 'O código está muito longo. Ex: PETR4 (máximo 6 caracteres)';
    }

    if (!RegExp(r'\d$').hasMatch(ticker)) {
      return 'O código deve terminar com um número. Ex: PETR4, VALE3';
    }

    return null;
  }

  void _buscarTicker(String value) {
    final tickerUpper = value.toUpperCase().trim();
    final erro = validarTicker(tickerUpper);

    if (erro != null) {
      setState(() {
        ticker = tickerUpper;
        _future = Future.error(erro);
      });
    } else {
      setState(() {
        ticker = tickerUpper;
        _future = apiService.buscarCotacao(tickerUpper);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(

      appBar: AppBar(
        backgroundColor: brapiCardBg,
      
        title: const Text(
          'BUSCAR COTAÇÃO',
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.w900,
            letterSpacing: 2.5,
            fontSize: 18,
          ),
        ),
        centerTitle: true,
        elevation: 0,
        //botão de voltar
        leading: IconButton(
          onPressed: () {
            Navigator.pop(context);
          },
          icon: const Icon(Icons.arrow_back, color: brapiBlue),
        ),

        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(3),
          child: BarraTecnologica(color: brapiBlue),
        ),
      ),
      // fundo da pagina
      backgroundColor: brapiDarkBg,
      body: Padding(
        padding: const EdgeInsets.all(10.0),
        child: Column(
          children: <Widget>[
            // CAMPO DE TEXTO
            Container(
              decoration: BoxDecoration(
                color: brapiCardBg,
                border: Border.all(color: brapiBlue, width: 2),
                borderRadius: BorderRadius.circular(8),
                boxShadow: [
                  BoxShadow(color: brapiBlue.withOpacity(0.15), blurRadius: 8),
                ],
              ),
              // campo de texto para digitar o código da ação
              child: TextField(
                controller: _textController,
                decoration: const InputDecoration(
                  labelText: "CÓDIGO DA AÇÃO (EX: PETR4)",
                  labelStyle: TextStyle(
                    color: Colors.white,
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                    letterSpacing: 1.5,
                  ),
                  border: InputBorder.none,
                  contentPadding: EdgeInsets.all(16),
                  prefixIcon: Icon(Icons.terminal, color: brapiBlue),
                ),
                // estilo do texto digitado
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 18,
                  fontWeight: FontWeight.w700,
                  letterSpacing: 2,
                ),
                // configurações do campo de texto
                textCapitalization: TextCapitalization.characters,
                onSubmitted: _buscarTicker,
              ),
            ),

            const SizedBox(height: 10),

            // Resultado
            Expanded(
              child: _future == null
                  ? _dicasDeBusca()
                  : FutureBuilder<Map<String, dynamic>>(
                      future: _future,
                      builder: (context, snapshot) {
                        // Trata os diferentes estados da Future
                        switch (snapshot.connectionState) {
                          
                          case ConnectionState.waiting:
                          // Exibe indicador de carregamento
                            return const Center(
                              child: CircularProgressIndicator(
                                valueColor: AlwaysStoppedAnimation<Color>(
                                  brapiBlue,
                                ),
                                strokeWidth: 3.0,
                              ),
                            );
                          case ConnectionState.none:
                            return const Center(
                              child: CircularProgressIndicator(
                                valueColor: AlwaysStoppedAnimation<Color>(
                                  brapiBlue,
                                ),
                                strokeWidth: 3.0,
                              ),
                            );
                          default:
                          // Verifica se houve erro na busca
                            if (snapshot.hasError) {
                              return _exibirErro(snapshot.error.toString());
                            } else {
                              return DetalhesCotacaoWidget(
                                data: snapshot.data!,
                              );
                            }
                        }
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _dicasDeBusca() {
    return Center(

      child: Container(
        padding: const EdgeInsets.all(20),
        margin: const EdgeInsets.only(top: 20),
        decoration: BoxDecoration(
          color: brapiCardBg,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: brapiBlue.withOpacity(0.4)),
        ),
        // dicas para o usuário
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: const [
            Icon(Icons.search, size: 50, color: brapiBlue),
            SizedBox(height: 15),

            Text(
              "Digite o código de uma ação acima",
              style: TextStyle(
                color: Colors.white,
                fontSize: 14,
                letterSpacing: 1,
              ),
            ),
            SizedBox(height: 4),

            Text(
              "Exemplos: PETR4, VALE3, BBAS3...",
              style: TextStyle(color: Colors.white70, fontSize: 13),
            ),
          ],
        ),
      ),
    );
  }

  Widget _exibirErro(String errorMsg) {
    String displayMsg;
    // Personaliza a mensagem de erro para o usuário
    if (!errorMsg.contains('Exception:')) {
      displayMsg = errorMsg;
      // mensagem original
    } else if (errorMsg.contains('404') ||
        errorMsg.contains('não encontrad') ||
        errorMsg.contains('not found')) {
      displayMsg = 'Ação "$ticker" não encontrada na base de dados';
    } else {
      // remove o prefixo "Exception: "
      displayMsg = errorMsg.replaceFirst('Exception: ', '');
    }

    return Center(
      // exibe a mensagem de erro
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(Icons.error_outline, color: Colors.red, size: 70),
          const SizedBox(height: 20),
          const Text(
            "ERRO",
            style: TextStyle(
              color: Colors.red,
              fontWeight: FontWeight.w900,
              fontSize: 16,
              letterSpacing: 2,
            ),
          ),
          const SizedBox(height: 8),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 30),
            child: Text(
              displayMsg,
              textAlign: TextAlign.center,
              style: const TextStyle(color: Colors.white70, fontSize: 14),
            ),
          ),
        ],
      ),
    );
  }
}

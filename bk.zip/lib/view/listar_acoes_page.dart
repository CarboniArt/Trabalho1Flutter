import 'package:flutter/material.dart';
import '../service/brapi_service.dart';
import '../widgets/barra_tecnologica.dart';
import 'buscar_cotacao_page.dart';

class ListarAcoesPage extends StatefulWidget {
  const ListarAcoesPage({super.key});

  @override
  State<ListarAcoesPage> createState() => _ListarAcoesPageState();
}

class _ListarAcoesPageState extends State<ListarAcoesPage> {
  final apiService = BrapiService();
  late Future<List<dynamic>> _future;

  static const Color brapiBlue = Color(0xFF3B82F6);
  static const Color brapiDarkBg = Color(0xFF0F172A);
  static const Color brapiCardBg = Color(0xFF1E293B);
  static const Color brapiAccent = Color(0xFF60A5FA);

  @override
  void initState() {
    super.initState();
    _future = apiService.listarAcoesPopulares();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(

      appBar: AppBar(
        backgroundColor: brapiCardBg,
        title: const Text(
          'AÇÕES POPULARES',
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.w900,
            letterSpacing: 2.5,
            fontSize: 18,
          ),
        ),
        centerTitle: true,
        elevation: 0,

        //voltar
        leading: IconButton(
          onPressed: () => Navigator.pop(context),
          icon: const Icon(Icons.arrow_back, color: brapiBlue),
        ),

        //barra tecnologica
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(3),
          child: BarraTecnologica(color: brapiBlue),
        ),
      ),
      backgroundColor: brapiDarkBg,

      body: FutureBuilder<List<dynamic>>(
        future: _future,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(
              child: CircularProgressIndicator(
                valueColor: AlwaysStoppedAnimation<Color>(brapiBlue),
                strokeWidth: 3.0,
              ),
            );
          } else if (snapshot.hasError) {

            // Exibe mensagem de erro
            return Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(Icons.error_outline, color: Colors.red, size: 70),
                  const SizedBox(height: 20),
                  Text(
                    snapshot.error.toString().replaceFirst('Exception: ', ''),
                    style: const TextStyle(color: Colors.red, fontSize: 14),
                    textAlign: TextAlign.center,
                  ),
                ],
              ),
            );

            
          } else if (snapshot.hasData) {

            // Exibe a lista de ações populares
            final acoes = snapshot.data!;
            return ListView.builder(
              padding: const EdgeInsets.all(10),
              itemCount: acoes.length > 50 ? 50 : acoes.length,
              itemBuilder: (context, index) {
                final acao = acoes[index];

                // Exibe cada ação popular na lista
                return Container(
                  margin: const EdgeInsets.only(bottom: 10),
                  decoration: BoxDecoration(
                    color: brapiCardBg,
                    border: Border.all(color: brapiBlue, width: 1.5),
                    borderRadius: BorderRadius.circular(8),
                    boxShadow: [
                      BoxShadow(
                        // ignore: deprecated_member_use
                        color: brapiBlue.withOpacity(0.1),
                        blurRadius: 8,
                      ),
                    ],
                  ),

                  // Lista de ações
                  child: ListTile(
                    contentPadding: const EdgeInsets.symmetric(
                      horizontal: 16,
                      vertical: 8,
                    ),

                    // Símbolo da ação
                    leading: Container(
                      width: 45,
                      height: 45,
                      decoration: BoxDecoration(
                        // ignore: deprecated_member_use
                        color: brapiBlue.withOpacity(0.15),
                        border: Border.all(color: brapiBlue, width: 1.5),
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: Center(
                        // Primeiras duas letras do símbolo
                        child: Text(
                          acao['stock']?.substring(0, 2) ?? '??',
                          style: const TextStyle(
                            color: brapiBlue,
                            fontWeight: FontWeight.w900,
                            fontSize: 14,
                            letterSpacing: 1,
                          ),
                        ),
                      ),
                    ),
                    // Símbolo da ação
                    title: Text(
                      acao['stock'] ?? '-',
                      style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w900,
                        fontSize: 16,
                        letterSpacing: 1.5,
                      ),
                    ),
                    // Nome da ação
                    subtitle: Text(
                      acao['name'] ?? '-',
                      style: const TextStyle(
                        color: brapiAccent,
                        fontSize: 11,
                        fontWeight: FontWeight.w600,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    // Ícone de seta para indicar navegação
                    trailing: const Icon(
                      Icons.arrow_forward,
                      color: brapiBlue,
                      size: 20,
                    ),

                    
                    onTap: () => _navegarParaDetalhes(context, acao['stock']),
                  ),
                );
              },
            );
          } else {
            return const Center(
              child: Text(
                "Nenhuma ação disponível",
                style: TextStyle(color: Colors.white54),
              ),
            );
          }
        },
      ),
    );
  }

  void _navegarParaDetalhes(BuildContext context, String? ticker) {
    if (ticker == null) return;

    // Navega para a tela de buscar cotação passando o ticker
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => BuscarCotacaoPage(tickerInicial: ticker),
      ),
    );
  }
}
